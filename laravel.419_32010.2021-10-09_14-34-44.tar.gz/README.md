# SLC Backend

### This backend uses Laravel - Voyager